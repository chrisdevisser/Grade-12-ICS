package u3a2_chrisdevisser_recursion;

/**
 *
 * @author Chris DeVisser
 */
public class Main {
    /**
     * @param args The command line arguments
     */
    public static void main(String[] args) {
        new Gui().setVisible(true);
    }

    private Main(){}
}
